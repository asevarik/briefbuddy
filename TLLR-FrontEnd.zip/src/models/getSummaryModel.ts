export  interface GetSummaryModel{
    url:string,
    expected_response:string,
    prompt_type:number
}