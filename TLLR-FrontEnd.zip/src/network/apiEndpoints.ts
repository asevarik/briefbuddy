export const apiEndPoints = {
    getSummary:'/get_summary/',
}
export const BASE_URL = "http://localhost:8000"

